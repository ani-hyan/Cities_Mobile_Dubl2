package com.example.cities_mobile_dubl2.viewmodel

import androidx.lifecycle.ViewModel

class WelcomeViewModel {
}